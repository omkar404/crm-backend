// require("dotenv").config();
// const express = require("express");
// const cors = require("cors");
// require("./src/config/db");

// const leadRoutes = require("./src/routes/leadRoutes");

// const app = express();
// // app.use(cors());

// app.use(cors({ origin: "http://localhost:5173", credentials: true }));
// app.use(express.json());

// app.use("/api/auth", leadRoutes);

// app.get("/", (req, res) => {
//   res.status(200).json({
//     success: true,
//     message: "CRM Backend is running 🚀",
//   });
// });

// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => {
//   console.log(`Server started on port ${PORT}`);
//   // console.log("MONGO_URI =", process.env.MONGO_URI?.replace(/\/\/.*@/, "//****@"));
// });


// require("dotenv").config();
// const express = require("express");
// const cors = require("cors");
// const connectDB = require("./src/config/db");
// const cookieParser = require("cookie-parser");
// const mongoose = require("mongoose");
// const { errorHandler } = require( "./src/middleware/error");


// const leadRoutes = require("./src/routes/leadRoutes");
// // const cha = require("./src/routes/workdeskCha.routes");
// // const workdeskClient = require("./src/routes/workdeskClient.routes");
// // const taskRoutes = require("./src/routes/workdeskTask.routes");
// // const invoiceRoutes = require("./src/routes/invoice.routes");
// // const workdeskTaskFilterRoutes = require("./src/routes/workdeskTaskFilter.routes");
// // const workdeskDashboardRoutes = require("./src/routes/workdeskDashboard.routes");

// const app = express();

// // app.use(cors({
// //   origin: "https://eximinq.co.in",
// //   credentials: true
// // }));


// // app.use(cors({
// //   // origin: "https://eximinq.co.in",
// //   origin: "http://localhost:5173",
// //   credentials: true,
// //   methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
// //   allowedHeaders: ["Content-Type", "Authorization"]
// // }));

// // app.options("/*", cors());

// // app.use(cors());

// app.use(cors({
//   origin: "http://localhost:5173",
//   // credentials: true
// }));

// app.use(express.json());
// app.use(cookieParser());

// app.use("/api/auth", leadRoutes);
// // app.use("/workdesk/auth", require("./src/routes/workdeskAuth.routes"));
// // app.use("/workdesk", cha);
// // app.use("/workdesk", workdeskClient);
// // app.use("/workdesk", taskRoutes);
// // app.use("/workdesk", invoiceRoutes);
// // app.use("/workdesk", workdeskTaskFilterRoutes);
// // app.use("/workdesk", workdeskDashboardRoutes);

// app.get("/", (req, res) => {
//   res.status(200).json({
//     success: true,
//     message: "CRM Backend is running 🚀",
//   });
// });

// // 404 handler
// app.use((req, res, next) => {
//   res.status(404);
//   next(new Error("Route not found"));
// });

// app.use(errorHandler);

// const PORT = process.env.PORT || 5000;

// const startServer = async () => {
//   await connectDB();

//   app.listen(PORT, () => {
//     console.log(`Server started on port ${PORT}`);
//   });
// };

// startServer();
// // const PORT = process.env.PORT || 5000;
// // app.listen(PORT, () => {
// //   console.log(`Server started on port ${PORT}`);
// // });



require("dotenv").config();
const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");

const connectDB = require("./src/config/db");
const leadRoutes = require("./src/routes/leadRoutes");
const { errorHandler } = require("./src/middleware/error");

const app = express();

app.use(cors({
  // origin: "http://localhost:5173",
  origin: [
    "https://eximinq.co.in",
    "https://www.eximinq.co.in",
    "http://localhost:5173"
  ],

  methods: ["GET","POST","PUT","PATCH","DELETE","OPTIONS"],
  allowedHeaders: ["Content-Type","Authorization"]
}));

app.use(express.json());
app.use(cookieParser());

app.use("/api/auth", leadRoutes);

app.get("/", (req, res) => {
  res.json({ success: true });
});

app.use(errorHandler);

connectDB().then(() => {
  app.listen(5000, () => {
    console.log("Server running on 5000");
  });
});