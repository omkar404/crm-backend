import mongoose from "mongoose";

const chaSchema = new mongoose.Schema(
  {
    chaname: { type: String, required: true },
    contactPerson: { type: String },
    mobile: { type: String },
    email: { type: String },
    officeAddress: { type: String },
    remarks: { type: String },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  },
  { timestamps: true }
);

export default mongoose.model("CHA", chaSchema);
